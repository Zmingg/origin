<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Cate extends Model
{
    // protected $table = 'cates';

	// 关闭自动存储更新时间 created_at/update_at
    public $timestamps = false;


}