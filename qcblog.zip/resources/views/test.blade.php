<form method="post" action="{{url('oauth/code')}}">
	<label>用户名</label><input type="text" name="user">
	<label>密码</label><input type="text" name="pass">
	<button type="submit">授权并登陆</a>
</form>
