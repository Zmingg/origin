<?php

  Phpinfo();